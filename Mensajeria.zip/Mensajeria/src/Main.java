import com.neoris.equipodinamita.caracteristicasvehiculo.*;
import com.neoris.equipodinamita.menu.Menu;
import com.neoris.equipodinamita.reportegas.ReporteCombustible;
import com.neoris.equipodinamita.transporte.*;

import java.util.Scanner;


public class Main {

    public static void main(String[] args) {

        boolean salir = false;
        Scanner entrada = new Scanner(System.in);

        while (!salir){
            try{
                Menu.mostrarMenu();
                salir = Menu.ejecutarOpciones(entrada);
            } catch (Exception ex){
                System.out.println("Ocurrio un error: " + ex.getMessage());
            }
            System.out.println();
        }

    }

}