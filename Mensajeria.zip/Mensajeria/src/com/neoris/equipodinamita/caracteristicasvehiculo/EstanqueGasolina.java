package com.neoris.equipodinamita.caracteristicasvehiculo;

public class EstanqueGasolina {
    private int capacidad;

    public EstanqueGasolina(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getCapacidad() {
        return capacidad;
    }

}
