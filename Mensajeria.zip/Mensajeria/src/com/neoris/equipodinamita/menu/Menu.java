package com.neoris.equipodinamita.menu;

import com.neoris.equipodinamita.caracteristicasvehiculo.DistanciaRecorrida;
import com.neoris.equipodinamita.caracteristicasvehiculo.EstanqueGasolina;
import com.neoris.equipodinamita.caracteristicasvehiculo.Persona;
import com.neoris.equipodinamita.caracteristicasvehiculo.TipoAutomovil;
import com.neoris.equipodinamita.reportegas.ReporteCombustible;
import com.neoris.equipodinamita.transporte.Vehiculo;

import java.util.Scanner;

public class Menu {

    public static void mostrarMenu(){
        System.out.print("""
                ********* CONTROL DE TRANSPORTE (MENSAJERIA DINAMITA) *********
                1. Motocicleta
                2. Automovil
                3. Camioneta
                4. Salir
                Selecciona el vehiculo para generar el Reporte de gasto de combustible: 
                """);
    }

    public static boolean ejecutarOpciones(Scanner entrada) {
        int opcion = Integer.parseInt(entrada.nextLine());
        boolean salir = false;

        switch (opcion) {
            case 1 -> {
                System.out.println("--------Motocicleta---------");
                Vehiculo moto = new Vehiculo();
                System.out.println("Agrega los siguientes datos");
                System.out.print("Ingresa la marca de la motocicleta: ");
                String marca = entrada.nextLine();
                System.out.print("Ingresa el modelo de la motocicleta: ");
                String modelo = entrada.nextLine();
                System.out.print("Ingresa las placas de la motocicleta: ");
                String placas = entrada.nextLine();
                System.out.print("Ingresa la capacidad en litros de la motocicleta: ");
                int capacidad = entrada.nextInt();
                entrada.nextLine(); //Limpiar el buffer del scanner
                System.out.print("Ingresa el nombre del conductor: ");
                String nombre = entrada.nextLine();
                System.out.print("Ingresa el apellido del conductor: ");
                String apellido = entrada.nextLine();
                System.out.print("Ingresa la distancia recorrida en Km: ");
                double distancia = entrada.nextDouble();
                System.out.print("Ingresa la cantidad en litros de gasolina utilizada: ");
                double gasolinaGastada = entrada.nextDouble();

                moto.setMarca(marca);
                moto.setModelo(modelo);
                moto.setPlacas(placas);
                moto.setEstanqueGasolina(new EstanqueGasolina(40));
                moto.setConductor(new Persona(nombre, apellido));
                moto.setTipoVehiculo(TipoAutomovil.MOTO);
                moto.setDistanciaRecorrida(new DistanciaRecorrida(distancia, gasolinaGastada));
                ReporteCombustible.reporteCombustible(moto);
                entrada.nextLine();
            }
            case 2 -> {
                System.out.println("--------Automovil---------");
                Vehiculo auto = new Vehiculo();
                System.out.println("Agrega los siguientes datos");
                System.out.print("Ingresa la marca del automovil: ");
                String marca = entrada.nextLine();
                System.out.print("Ingresa el modelo del automovil: ");
                String modelo = entrada.nextLine();
                System.out.print("Ingresa las placas del automovil: ");
                String placas = entrada.nextLine();
                System.out.print("Ingresa la capacidad en litros del automovil: ");
                int capacidad = entrada.nextInt();
                entrada.nextLine(); //Limpiar el buffer del scanner
                System.out.print("Ingresa el nombre del conductor: ");
                String nombre = entrada.nextLine();
                System.out.print("Ingresa el apellido del conductor: ");
                String apellido = entrada.nextLine();
                System.out.print("Ingresa la distancia recorrida en Km: ");
                double distancia = entrada.nextDouble();
                System.out.print("Ingresa la cantidad en litros de gasolina utilizada: ");
                double gasolinaGastada = entrada.nextDouble();

                auto.setMarca(marca);
                auto.setModelo(modelo);
                auto.setPlacas(placas);
                auto.setEstanqueGasolina(new EstanqueGasolina(40));
                auto.setConductor(new Persona(nombre, apellido));
                auto.setTipoVehiculo(TipoAutomovil.AUTO);
                auto.setDistanciaRecorrida(new DistanciaRecorrida(distancia, gasolinaGastada));
                ReporteCombustible.reporteCombustible(auto);
                entrada.nextLine();
            }
            case 3 -> {
                System.out.println("--------Camioneta---------");
                Vehiculo camioneta = new Vehiculo();
                System.out.println("Agrega los siguientes datos");
                System.out.print("Ingresa la marca de la camioneta: ");
                String marca = entrada.nextLine();
                System.out.print("Ingresa el modelo de la camioneta: ");
                String modelo = entrada.nextLine();
                System.out.print("Ingresa las placas de la camioneta: ");
                String placas = entrada.nextLine();
                System.out.print("Ingresa la capacidad en litros de la camioneta: ");
                int capacidad = entrada.nextInt();
                entrada.nextLine(); //Limpiar el buffer del scanner
                System.out.print("Ingresa el nombre de la camioneta: ");
                String nombre = entrada.nextLine();
                System.out.print("Ingresa el apellido de la camioneta: ");
                String apellido = entrada.nextLine();
                System.out.print("Ingresa la distancia recorrida en Km: ");
                double distancia = entrada.nextDouble();
                System.out.print("Ingresa la cantidad en litros de gasolina utilizada: ");
                double gasolinaGastada = entrada.nextDouble();

                camioneta.setMarca(marca);
                camioneta.setModelo(modelo);
                camioneta.setPlacas(placas);
                camioneta.setEstanqueGasolina(new EstanqueGasolina(40));
                camioneta.setConductor(new Persona(nombre, apellido));
                camioneta.setTipoVehiculo(TipoAutomovil.AUTO);
                camioneta.setDistanciaRecorrida(new DistanciaRecorrida(distancia, gasolinaGastada));
                ReporteCombustible.reporteCombustible(camioneta);
                entrada.nextLine();
            }
            case 4 -> {
                System.out.println("--------Saliendo---------");
                System.out.println("Hasta la proxima");
                salir = true;
            }
            default -> System.out.println("Opcion no reconocida: " + opcion);
        }
        System.out.println();
        return salir;

    }

}
